
console.log("StockIntel Website Ready");
